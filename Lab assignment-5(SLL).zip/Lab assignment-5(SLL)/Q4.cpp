#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* next;
    Node* prev;
    Node(int val){
        data = val;
        next = NULL;
        prev=NULL;
    }
    Node(int val,Node* nx){
        data = val;
        next = nx;
    }
};
class SLL{
    Node* head;
    Node* tail;
    public:
    SLL(){
        head = NULL;
        tail = NULL;
    }
    void insert_head(int val){
        Node* newnode = new Node(val);
        if(head==NULL){
            head = tail = newnode;
            
        }
        else{
            newnode->next = head;
            head = newnode;
        }
    }
    void insert_tail(int val){
        Node* newnode = new Node(val);
        if(head==NULL and tail==NULL){
            head = tail = newnode;
        }
        else{
            tail->next = newnode;
            tail = newnode;
        }
    }
    void insert_mid(int val,int key){
        Node* temp = head;
        while(temp->data!=key){
            temp = temp->next;
        }
        if(temp==tail){
            insert_tail(val);
        }
        else{
            Node* newnode = new Node(val);
            newnode->next = temp->next;
            temp->next = newnode;
        }

    }
    void reverse() {
        Node* prev = nullptr;
        Node* current = head;
        Node* next = nullptr;
        while (current != nullptr) {
            next = current->next;  
            current->next = prev;  
            prev = current;       
            current = next;        
        }
        head = prev;
    }
    void display(){
        Node* temp = head;
        while(temp!=NULL){
            cout<<temp->data<<" -> ";
            temp = temp->next;
        }
        cout<<endl;
    }
};
int main(){
    SLL list;
    list.insert_head(1);
    list.insert_tail(4);
    list.insert_head(2);
    list.insert_head(3);
    list.insert_mid(7,3);
    list.display();
    list.reverse();
    list.display();
}