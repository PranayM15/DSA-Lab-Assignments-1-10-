#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* next;
    Node* prev;
    Node(int val){
        data = val;
        next = NULL;
        prev=NULL;
    }
    Node(int val,Node* nx){
        data = val;
        next = nx;
    }
};
class SLL{
    Node* head;
    Node* tail;
    public:
    SLL(){
        head = NULL;
        tail = NULL;
    }
    void insert_head(int val){
        Node* newnode = new Node(val);
        if(head==NULL){
            head = tail = newnode;
            
        }
        else{
            newnode->next = head;
            head = newnode;
        }
    }
    void insert_tail(int val){
        Node* newnode = new Node(val);
        if(head==NULL and tail==NULL){
            head = tail = newnode;
        }
        else{
            tail->next = newnode;
            tail = newnode;
        }
    }
    void insert_mid(int val,int key){
        Node* temp = head;
        while(temp->data!=key){
            temp = temp->next;
        }
        if(temp==tail){
            insert_tail(val);
        }
        else{
            Node* newnode = new Node(val);
            newnode->next = temp->next;
            temp->next = newnode;
        }

    }
    void count_and_delete(int key){
    Node* temp = head;
    Node* prev = nullptr;
    int cnt = 0;
    while(head != nullptr && head->data == key){
        Node* del = head;
        head = head->next;
        delete del;
        cnt++;
    }

    temp = head;
    prev = nullptr;

    while(temp != nullptr){
        if(temp->data == key){
            cnt++;
            Node* del = temp;
            if(prev != nullptr) prev->next = temp->next;
            temp = temp->next;
            delete del;
        } else {
            prev = temp;
            temp = temp->next;
        }
    }
    cout << key << " is present " << cnt << " times" << endl;
}

    void display(){
        Node* temp = head;
        while(temp!=NULL){
            cout<<temp->data<<" -> ";
            temp = temp->next;
        }
        cout<<endl;
    }
};
int main(){
    SLL list;
    list.insert_head(1);
    list.insert_tail(1);
    list.insert_head(2);
    list.insert_head(3);
    list.insert_tail(5);
    list.insert_mid(1,3);
    list.display();
    list.count_and_delete(1);
    list.display();
}