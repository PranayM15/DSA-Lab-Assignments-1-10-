#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* next;
    Node(int val){
        data = val;
        next = NULL;
    }
    Node(int val,Node* nx){
        data = val;
        next = nx;
    }
};
class SLL{
    Node* head;
    Node* tail;
    public:
    SLL(){
        head = NULL;
        tail = NULL;
    }
    void insert_head(int val){
        Node* newnode = new Node(val);
        if(head==NULL){
            head = tail = newnode;
            
        }
        else{
            newnode->next = head;
            head = newnode;
        }
    }
    void insert_tail(int val){
        Node* newnode = new Node(val);
        if(head==NULL and tail==NULL){
            head = tail = newnode;
        }
        else{
            tail->next = newnode;
            tail = newnode;
        }
    }
    void insert_mid(int val,int key){
        Node* temp = head;
        while(temp->data!=key){
            temp = temp->next;
        }
        if(temp==tail){
            insert_tail(val);
        }
        else{
            Node* newnode = new Node(val);
            newnode->next = temp->next;
            temp->next = newnode;
        }

    }
    void delete_head(){
        if(head==NULL) return;
        if(head->next==NULL){
            delete head;
            return;
        }
        Node* temp = head;
        head = head->next;
        temp->next = NULL;
        delete temp;
    }
    void delete_tail(){
        if(head==NULL and tail==NULL) return;
        if(head==tail) head = tail = NULL;
        Node* temp = tail;
        Node* prev = head;
        while(prev->next!=tail){
            prev = prev->next;
        }
        tail = prev;
        tail->next = NULL;
        temp->next=NULL;
        delete temp;

    }
    void delete_mid(int key){
        Node* temp = head;
        while(temp->data!=key){
            temp = temp->next;
        }
        if(temp==head) delete_head();
        else if(temp==tail) delete_tail();
        else{
            Node* back = head;
            while(back->next!=temp){
                back = back->next;
            }
            back->next = temp->next;
            temp->next = NULL;
            delete temp;
        }
    }
    void search(int key){
        if(head==NULL){
            cout<<"Element not found"<<endl;
            return;
        }
        Node* temp = head;
        int pos=1;
        while(temp!=NULL and temp->data!=key){
            pos++;
            temp = temp->next;
        }
        if(temp==NULL){
            cout<<"Element not found"<<endl;
            return;
        }
        else{
            cout<<key<<" is present at Node "<<pos<<endl;
        }
    }
    void display(){
        Node* temp = head;
        while(temp!=NULL){
            cout<<temp->data<<" -> ";
            temp = temp->next;
        }
        cout<<endl;
    }
};
int main() {
    SLL list;
    int x;
    do {
        cout << "Choose the operation (0 to exit):\n";
        cout << "1. Insert at head\n";
        cout << "2. Insert at tail\n";
        cout << "3. Insert in middle\n";
        cout << "4. Delete head\n";
        cout << "5. Delete tail\n";
        cout << "6. Delete middle (by key)\n";
        cout << "7. Search\n";
        cout << "8. Display\n";
        cout << "0. Exit\n";
        cin >> x;

        switch (x) {
            case 1: {
                int val;
                cout << "Enter value to insert: ";
                cin >> val;
                list.insert_head(val);
                break;
            }
            case 2: {
                int val;
                cout << "Enter value to insert: ";
                cin >> val;
                list.insert_tail(val);
                break;
            }
            case 3: {
                int val, key;
                cout << "Enter value to insert: ";
                cin >> val;
                cout << "At what place to be inserted?: ";
                cin >> key;
                list.insert_mid(val, key);
                break;
            }
            case 4:
                list.delete_head();
                break;
            case 5:
                list.delete_tail();
                break;
            case 6: {
                int key;
                cout << "Enter value to delete: ";
                cin >> key;
                list.delete_mid(key);
                break;
            }
            case 7: {
                int key;
                cout << "Enter value to be searched: ";
                cin >> key;
                list.search(key);
                break;
            }
            case 8:
                list.display();
                break;
            case 0:
                return 0;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    } while (true);
}
